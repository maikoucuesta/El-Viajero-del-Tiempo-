# Cómo conseguir el .apk (gratis, sin instalar nada en tu PC)

Este proyecto ya trae Capacitor + notificaciones locales configuradas.
GitHub va a compilar el .apk por ti con GitHub Actions.

## Pasos

1. Ve a github.com, crea un repositorio nuevo (puede ser privado), por ejemplo `el-viajero-del-tiempo`.
2. Sube TODO el contenido de esta carpeta al repositorio (arrastrando los archivos en la web de GitHub, o con `git push` si usas terminal). No hace falta subir `node_modules` (ya está excluido).
3. Ve a la pestaña **Actions** de tu repositorio. Debería arrancar solo un workflow llamado "Compilar APK" (tarda 2-4 minutos).
4. Cuando termine (icono verde ✓), entra en esa ejecución y baja hasta **Artifacts**.
5. Descarga `el-viajero-del-tiempo-apk` — es un .zip que contiene el `app-debug.apk`.
6. Pásate ese .apk al móvil (por cable, Drive, WhatsApp a ti mismo...) y ábrelo para instalarlo. Android te pedirá permitir "instalar apps de origen desconocido" la primera vez — es normal, es tu propio archivo.

## Qué incluye ya

- La app completa con el motor de predicción corregido.
- Recordatorios reales: los hábitos con hora programada (pestaña Inicio) lanzan una notificación del sistema a esa hora, todos los días, aunque la app esté cerrada.
- Al abrir la app por primera vez te pedirá permiso de notificaciones — acéptalo o los recordatorios no sonarán.

## Nota sobre la firma

Este workflow genera un APK de **debug** (firmado con una clave de pruebas automática). Sirve perfectamente para instalarlo tú mismo. Si en el futuro quieres subirlo a Google Play, hay que generar una versión "release" firmada con tu propia clave — dímelo cuando llegues a ese punto y lo preparamos.
